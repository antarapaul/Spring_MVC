package org.cap.service;

public interface ILoginServie {

}
