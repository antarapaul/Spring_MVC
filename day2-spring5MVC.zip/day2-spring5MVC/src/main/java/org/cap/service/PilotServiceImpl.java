package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements IPilotService{
	
	@Autowired
	private IPilotDao pilotDao;
	
	@Override
	public void SavePilot(Pilot pilot) {
		pilotDao.SavePilot(pilot);
		
	}

	@Override
	public List<Pilot> getAllPilots() {
		
		return pilotDao.getAllPilots();
	}

	@Override
	public void DeletePilot(int pilotId) {
		pilotDao.DeletePilot(pilotId);
		
	}

	@Override
	public Pilot UpdatePilot(Pilot pilot) {
		return pilotDao.UpdatePilot(pilot);
		
	}

	@Override
	public Pilot findPilot(int pilotId) {
		
		return pilotDao.findPilot(pilotId);
	}

}
