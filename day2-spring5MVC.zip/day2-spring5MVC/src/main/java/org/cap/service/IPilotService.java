package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotService {
	public void SavePilot(Pilot pilot);
	public List<Pilot> getAllPilots();
	public void DeletePilot(int pilotId);
	public Pilot UpdatePilot(Pilot pilot);
	public Pilot findPilot(int pilotId);
}
