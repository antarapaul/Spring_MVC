package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("pilotDao")
public class PilotDaoImpl implements IPilotDao{
	
	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public void SavePilot(Pilot pilot) {
		
		 em.persist(pilot);
		 
	}

	@Override
	public List<Pilot> getAllPilots() {
		List<Pilot> pilots=em.createQuery("from Pilot").getResultList();
		return pilots;
	}

	@Override
	public void DeletePilot(int pilotId) {
		Pilot pilot=em.find(Pilot.class,pilotId);
		if(pilot!=null) {
			em.remove(pilot);
		}
		
	}

	@Override
	public Pilot UpdatePilot(Pilot pilot) {
		 return em.merge(pilot);
		
		
	}

	@Override
	public Pilot findPilot(int pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		if(pilot!=null) {
			return pilot;
		}
		return null;
	}

}
